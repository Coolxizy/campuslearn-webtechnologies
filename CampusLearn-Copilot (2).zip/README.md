# CampusLearn Infinity + Campus Copilot

`CampusLearn-Infinity.html` is your original site with **Campus Copilot — your personal CS study companion** added.
`server.js` serves the site and is the only place the AI key lives (zero dependencies, Node 20.12+).

## Start it (Windows)
1. Install Node.js LTS from https://nodejs.org/ (once).
2. Double-click **`start-windows.bat`**. The first time it creates `.env` and opens it in Notepad.
3. Replace `your-api-key-here` with your key from https://console.anthropic.com/, save, close Notepad.
4. Double-click **`start-windows.bat`** again. Your browser opens http://localhost:3000. Stop with Ctrl+C.

Manual alternative (any OS): copy `.env.example` to `.env`, edit the key, run `node server.js`, open http://localhost:3000.

## Using DeepSeek instead (no Anthropic key)
`deepseek-proxy/` is the unmodified community project FreeDeepseekAPI (MIT). It turns your own logged-in DeepSeek web chat into a local API on port 9655, and `server.js` can use it.
1. Install Node.js and Google Chrome.
2. Double-click **`start-with-deepseek.bat`**.
3. First time only: a menu opens → choose **1**, log in to DeepSeek in the Chrome window, send a message like "ok", return to the black window and press Enter.
4. Two black windows stay open (the proxy and CampusLearn); the site opens at http://localhost:3000 and the status should read **AI connected**.

Read before relying on it:
- It is **unofficial**: it drives DeepSeek's website with your saved login (`deepseek-proxy/deepseek-auth.json` = access to your account – never share or upload it). It can break whenever DeepSeek changes their site and may be against DeepSeek's terms. Fine for personal local study; **do not put it in front of other students or a public site** — everyone would share your one account and one conversation, and your account could be limited.
- Each question is sent to DeepSeek as a fresh chat that carries the recent history itself (so it doesn't answer old or imagined questions). Expect many small chats to pile up in your DeepSeek chat history; you can delete them there.
- Replies appear in chunks after DeepSeek finishes, not word by word.
- The "Stop" button stops the page, but DeepSeek may still finish in the background.
- If the proxy isn't running, or has no saved login, the status says the AI can't be reached and you fall back to the Offline helper. Re-run `npm run auth` inside `deepseek-proxy` when the login expires.
- For real use the official paid APIs (Anthropic or DeepSeek) are more reliable.

## What you will see
| Situation | Copilot status |
|---|---|
| Opened the HTML by double-click (`file://`) | Offline course helper – "opened as a file — no server" |
| `node server.js`, no key | Offline course helper – "no API key on the server" |
| Key rejected by the provider | Connection error – "the server's API key was rejected" |
| Key valid and provider reachable | AI connected |

The status comes from a real check (`GET /api/health` asks the provider whether the key works). It is never assumed.
The Offline course helper works without any server: it searches the course content, converts number systems with exact local code, runs practice quizzes from the course question bank, and opens lessons/labs. It is labelled as such and is not an AI.

## Connecting the AI (guide)
1. Create an API key in the Anthropic Console. Keep it private; never paste it into the HTML or chat.
2. Put it in `.env` as `ANTHROPIC_API_KEY=...`. Optionally change `ANTHROPIC_MODEL` (default `claude-sonnet-5-5`).
3. Restart `node server.js`. Open the Copilot; the status should read **AI connected**.
4. Deploying to a real site: serve over HTTPS, set `ALLOWED_ORIGINS` if the page is on a different origin than the server, set `TRUST_PROXY=1` only behind a reverse proxy you control, and consider `GLOBAL_DAILY_LIMIT` to cap spend.
5. Troubleshooting: "server not reachable" = you opened the file directly or the server is stopped; "key rejected" = wrong/revoked key; "AI service can't be reached" = network/provider outage. Use the **Reconnect** button after fixing.

## Files
`CampusLearn-Infinity.html` site · `server.js` backend · `start-with-deepseek.bat` + `deepseek-proxy/` optional DeepSeek route · `package.json` · `.env.example` placeholders only · `start-windows.bat` · `tests/` automated suites (`node tests/server.test.js`, needs no key) · `screenshots/` · `TEST-REPORT.md` · `IMPLEMENTATION.md`

## Privacy in one paragraph
Chats are stored only in your browser (`campuslearn.copilot.v1.*` keys; limit 30 chats × 80 messages), can be turned off or cleared in the History drawer, and never touch `campuslearn.state`. In connected mode the server forwards your message, the last 10 messages, short course excerpts and anything you explicitly attach/enable (lesson context, progress summary, notes, code, selection) to the provider. Nothing is logged with message content.
