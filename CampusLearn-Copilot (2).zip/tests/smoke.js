const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const path = require('path');
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 1366, height: 800 } });
  const errs = []; p.on('pageerror', e => errs.push('PAGEERR ' + e.message)); p.on('console', m => { if (m.type() === 'error') errs.push('CONSOLE ' + m.text()); });
  await p.goto('file://' + path.resolve(__dirname, '../CampusLearn-Infinity.html') + '?cc_test=1');
  await p.waitForTimeout(1500);
  console.log('launcher', await p.locator('#cc-launcher').count());
  await p.click('#cc-launcher'); await p.waitForTimeout(500);
  console.log('status:', await p.locator('.cc-status').innerText());
  await p.screenshot({ path: '/tmp/shot1.png' });
  console.log('errors', errs);
  await b.close();
})();
