const { chromium, check, newPage, openChat, send, waitIdle, results } = require('./lib');
const startServer = require('./run-server'); const fs = require('fs'); const path = require('path');
const SHOT = path.join(__dirname, '..', 'screenshots'); fs.mkdirSync(SHOT, { recursive: true });
(async () => {
  const srv = await startServer({ ANTHROPIC_API_KEY: '' }, 3917);
  const b = await chromium.launch();
  // ---------- responsive ----------
  for (const [name, vp] of [['mobile', { width: 390, height: 844 }], ['tablet', { width: 820, height: 1100 }], ['desktop', { width: 1366, height: 800 }]]) {
    const p = await newPage(b, srv.url + '/?cc_test=1', { viewport: vp, ctx: name === 'mobile' ? { hasTouch: true, isMobile: true } : {} });
    await openChat(p); await send(p, 'show me a python loop example with code'); await p.waitForTimeout(700);
    const m = await p.evaluate(() => { const pn = document.querySelector('#cc-panel'), r = pn.getBoundingClientRect(); return { ow: document.documentElement.scrollWidth - innerWidth, panelW: r.width, panelH: r.height, pnOverflow: pn.scrollWidth - pn.clientWidth, inVp: r.right <= innerWidth + 1 && r.bottom <= innerHeight + 1, inputVisible: (() => { const i = document.querySelector('.cc-input').getBoundingClientRect(); return i.bottom <= innerHeight + 1 && i.top >= 0; })() }; });
    check(name + ': no horizontal page overflow', m.ow <= 1, m);
    check(name + ': panel inside viewport, composer visible', m.inVp && m.inputVisible && m.pnOverflow <= 1, m);
    if (name === 'mobile') check('mobile: panel is full-screen', m.panelW >= 388 && m.panelH >= 800, m);
    await p.screenshot({ path: path.join(SHOT, name + '-light.png') });
    check(name + ': no page errors', p.errs.length === 0, p.errs);
    await p.context().close();
  }
  // ---------- long code scrolls inside block ----------
  let p = await newPage(b, srv.url + '/?cc_test=1', { viewport: { width: 390, height: 844 }, ctx: { hasTouch: true, isMobile: true } });
  await openChat(p);
  const long = '```\n' + 'x'.repeat(300) + '\n```';
  await p.evaluate(t => { /* inject a message through the UI path is unavailable; use input */ }, long);
  await p.fill('.cc-input', 'Explain this:\n' + long); await p.click('.cc-send'); await p.waitForTimeout(700);
  const ov = await p.evaluate(() => ({ page: document.documentElement.scrollWidth - innerWidth, pre: [...document.querySelectorAll('.cc-msg pre')].map(e => [e.scrollWidth > e.clientWidth, getComputedStyle(e).overflowX]) }));
  check('long code line scrolls inside its block, page does not overflow', ov.page <= 1 && (!ov.pre.length || ov.pre.every(x => /auto|scroll/.test(x[1]))), ov);
  await p.context().close();

  // ---------- themes while open + escape + shortcuts ----------
  p = await newPage(b, srv.url + '/?cc_test=1'); await openChat(p);
  await send(p, 'Explain RAM'); await p.waitForTimeout(500);
  const bg = () => p.evaluate(() => getComputedStyle(document.querySelector('#cc-panel')).backgroundColor);
  const b1 = await bg(); await p.evaluate(() => document.getElementById('theme-toggle').click()); await p.waitForTimeout(400); const b2 = await bg();
  check('panel recolours when the site theme toggles while open', b1 !== b2, [b1, b2]);
  await p.screenshot({ path: path.join(SHOT, 'desktop-dark.png') });
  await p.waitForTimeout(900); const norm = x => x.replace(/vt-theme/g,'').replace(/\s+/g,' '); const hashBefore = norm(await p.evaluate(() => location.hash + '|' + document.documentElement.className + '|' + document.body.className));
  await p.click('.cc-input'); for (const k of ['f', 't', '/', 'ArrowRight', 'ArrowLeft', 'g', '?', 'n']) await p.keyboard.press(k);
  const after = await p.evaluate(() => ({ v: document.querySelector('.cc-input').value, state: location.hash + '|' + document.documentElement.className + '|' + document.body.className, dlg: !!document.querySelector('dialog[open], .modal.open, [role=dialog]:not([hidden])') }));
  check('typing in composer: letters reach the textarea', after.v === 'ftg?n/', after.v);
  check('typing in composer: site shortcuts did not fire (route/theme/dialogs unchanged)', norm(after.state) === hashBefore, [hashBefore, norm(after.state)]);
  await p.keyboard.press('Escape'); await p.waitForTimeout(300);
  check('Escape closes panel and returns focus to launcher', !(await p.locator('#cc-panel').isVisible()) && await p.evaluate(() => document.activeElement && document.activeElement.id === 'cc-launcher'));
  await p.context().close();

  // ---------- history: rename / export / delete / clear / save toggle ----------
  p = await newPage(b, srv.url + '/?cc_test=1'); await openChat(p);
  await send(p, 'Explain RAM'); await p.waitForTimeout(500); await p.click('.cc-hbtns [aria-label="New chat"]'); await send(p, 'What is a CPU?'); await p.waitForTimeout(500);
  await p.click('[aria-label="Chat history and privacy"]'); await p.waitForTimeout(200);
  check('history lists both chats', (await p.locator('.cc-conv').count()) === 2);
  await p.locator('[aria-label^="Rename chat"]').first().click(); await p.keyboard.press('Control+a'); await p.keyboard.type('My renamed chat'); await p.keyboard.press('Enter'); await p.waitForTimeout(200);
  check('rename works', (await p.locator('.cc-conv').allInnerTexts()).some(t => /My renamed chat/.test(t)));
  const [dl] = await Promise.all([p.waitForEvent('download'), p.locator('[aria-label^="Export chat as Markdown"]').first().click()]);
  const f = await dl.path(); const md = fs.readFileSync(f, 'utf8');
  check('export downloads Markdown with messages', /\.md$/.test(dl.suggestedFilename()) && /RAM|CPU/.test(md), [dl.suggestedFilename(), md.slice(0, 120)]);
  const saved = await p.evaluate(() => Object.keys(localStorage).filter(k => /copilot/i.test(k)));
  check('history stored under a versioned Copilot namespace only', saved.length >= 1 && saved.every(k => /copilot.*v\d|cc\./i.test(k)), saved);
  await p.locator('[aria-label^="Delete chat"]').first().click(); await p.locator('[aria-label^="Confirm delete"]').first().click(); await p.waitForTimeout(200);
  check('delete (two-step) removes one chat', (await p.locator('.cc-conv').count()) === 1);
  // save toggle off
  await p.locator('.cc-sw input[role=switch]').filter({ hasText: '' }).last().uncheck(); await p.waitForTimeout(500);
  const afterOff = await p.evaluate(() => Object.keys(localStorage).filter(k => /copilot/i.test(k) && /conv/i.test(k)));
  check('turning saving off removes stored chats', afterOff.length === 0, afterOff);
  await p.locator('.cc-sw input[role=switch]').last().check(); await p.waitForTimeout(500);
  await p.click('.cc-btn.danger'); await p.click('.cc-btn.danger'); await p.waitForTimeout(300);
  check('clear all empties history', (await p.locator('.cc-conv').count()) === 0);
  await p.context().close();

  // ---------- persistence across reload & storage failure ----------
  p = await newPage(b, srv.url + '/?cc_test=1'); await openChat(p); await send(p, 'Explain RAM'); await p.waitForTimeout(900);
  await p.reload(); await p.waitForTimeout(700); await openChat(p);
  check('chat survives reload', (await p.locator('.cc-msg').count()) >= 2);
  await p.context().close();
  const ctx = await b.newContext(); await ctx.addInitScript(() => { const bad = { get() { throw new DOMException('denied', 'SecurityError'); } }; Object.defineProperty(window, 'localStorage', bad); });
  p = await ctx.newPage(); p.errs = []; p.on('pageerror', e => p.errs.push(e.message)); await p.goto(srv.url + '/?cc_test=1'); await p.waitForTimeout(800);
  const launcher = await p.locator('#cc-launcher').count(); await openChat(p); await send(p, 'Explain RAM'); await p.waitForTimeout(600);
  check('storage blocked: Copilot still works for the session', launcher === 1 && (await p.locator('.cc-msg').count()) >= 2, p.errs);
  check('storage blocked: no uncaught errors from Copilot', !p.errs.some(e => /cc|copilot|denied/i.test(e)), p.errs);
  await ctx.close();

  // ---------- attachments ----------
  p = await newPage(b, srv.url + '/?cc_test=1#/module/1/3'); await openChat(p); await p.waitForTimeout(300);
  await p.click('[aria-label="Attach context to your question"]');
  const items = await p.locator('.cc-menu button').allInnerTexts();
  check('attach menu offers selection, code, notes', items.length >= 3, items);
  await p.locator('.cc-menu button', { hasText: 'notes' }).first().click(); await p.waitForTimeout(300);
  check('attaching empty notes does not attach, and says so', (await p.locator('.cc-attitem').count()) === 0);
  await p.evaluate(() => { const t = document.querySelector('#lp-code, textarea.code, textarea'); });
  await p.context().close();

  // ---------- navigation while chatting ----------
  p = await newPage(b, srv.url + '/?cc_test=1#/module/1/1'); await openChat(p); await send(p, 'help me with this lesson'); await p.waitForTimeout(500);
  await p.evaluate(() => { location.hash = '#/module/2/2'; }); await p.waitForTimeout(500);
  const ctxTxt = await p.locator('.cc-chip.on').first().innerText();
  check('context chip follows lesson navigation', /Module 2/.test(ctxTxt), ctxTxt);
  check('navigation keeps the chat intact', (await p.locator('.cc-msg').count()) >= 2);
  await p.context().close();

  // ---------- regression: original flows, original vs updated ----------
  async function regress(url, label) {
    const q = await newPage(b, url); const r = {};
    r.errs0 = q.errs.length;
    await q.evaluate(() => document.getElementById('t-quiz').click()).catch(() => {}); await q.waitForTimeout(300);
    r.quizVisible = await q.evaluate(() => { const e = document.querySelector('#t-quiz'); return !!e; });
    await q.evaluate(() => document.getElementById('theme-toggle').click()); r.themeChanged = await q.evaluate(() => document.documentElement.getAttribute('data-theme') || document.documentElement.className);
    await q.evaluate(() => { location.hash = '#/module/1/1'; }); await q.waitForTimeout(500);
    r.lessonRendered = await q.evaluate(() => document.body.innerText.includes('Introduction to Computers'));
    r.state = await q.evaluate(() => { const s = localStorage.getItem('campuslearn.state'); try { return s ? Object.keys(JSON.parse(s)).sort().join(',') : null; } catch (e) { return 'bad'; } });
    r.errs = q.errs.slice(); await q.context().close(); return r;
  }
  const o = await regress('file:///home/claude/work/orig.html', 'orig'), n = await regress(srv.url + '/', 'new');
  check('regression: lesson route renders as in original', o.lessonRendered === n.lessonRendered && n.lessonRendered, [o, n]);
  check('regression: theme toggle behaves as original', o.themeChanged === n.themeChanged, [o.themeChanged, n.themeChanged]);
  check('regression: campuslearn.state keys identical to original', o.state === n.state, [o.state, n.state]);
  check('regression: no new page errors vs original', n.errs.length <= o.errs.length, n.errs);
  // Copilot never writes campuslearn.state
  p = await newPage(b, srv.url + '/?cc_test=1'); await p.evaluate(() => localStorage.setItem('campuslearn.state', JSON.stringify({ sentinel: 1 })));
  await openChat(p); await send(p, 'quiz me on binary'); await p.waitForTimeout(700); await send(p, 'Explain RAM'); await p.waitForTimeout(500);
  const st = await p.evaluate(() => localStorage.getItem('campuslearn.state'));
  check('Copilot chat leaves campuslearn.state byte-for-byte untouched', st === JSON.stringify({ sentinel: 1 }), st);
  await p.context().close();

  await b.close(); srv.stop();
  const f2 = results.filter(r => !r.ok).length; console.log('\nMISC SUITE: ' + (results.length - f2) + ' passed, ' + f2 + ' failed'); process.exit(f2 ? 1 : 0);
})().catch(e => { console.log('SUITE CRASH', e); process.exit(2); });
