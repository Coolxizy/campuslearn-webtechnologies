const { chromium, check, newPage, openChat, send, results } = require('./lib');
const startServer = require('./run-server'); const mock = require('./mock-upstream');
(async () => {
  const up = await mock.start(3921, { delay: 5 });
  const srv = await startServer({ ANTHROPIC_API_KEY: 'test-key-not-real', ANTHROPIC_BASE_URL: 'http://127.0.0.1:3921', RATE_LIMIT_PER_MINUTE: '60' }, 3918);
  const b = await chromium.launch(); const p = await newPage(b, srv.url + '/?cc_test=1');
  await p.evaluate(() => localStorage.setItem('campuslearn.state', '{"sentinel":1}'));
  await openChat(p); await p.waitForTimeout(800);
  await send(p, 'quiz me'); await p.waitForSelector('#cc-q-src');
  check('AI source option enabled when connected', !(await p.locator('#cc-q-src option[value=ai]').evaluate(o => o.disabled)));
  await p.selectOption('#cc-q-n', '3'); await p.selectOption('#cc-q-src', 'ai'); await p.click('text=Start practice');
  await p.waitForSelector('.cc-opt', { timeout: 6000 });
  check('AI quiz shows "AI-written" label', /AI-written/.test(await p.locator('.cc-meta').last().innerText()));
  check('answer key not exposed before answering (no .ok marker)', (await p.locator('.cc-opt.ok').count()) === 0);
  const stored = await p.evaluate(() => JSON.stringify(Object.entries(localStorage).filter(([k]) => /copilot|cc\./i.test(k))));
  const dom = await p.locator('.cc-card').last().innerHTML();
  check('question text visible but no "answer"/"correct" fields in DOM', !/data-answer|"answer"/.test(dom));
  await p.locator('.cc-opt').first().click(); await p.waitForSelector('.cc-fb');
  check('feedback shown after answering', (await p.locator('.cc-fb').count()) === 1);
  for (let i = 0; i < 6; i++) { await p.click('[data-next]'); await p.waitForTimeout(250); if (await p.locator('.cc-score').count()) break; await p.locator('.cc-opt').first().click(); await p.waitForTimeout(150); }
  await p.waitForSelector('.cc-score', { timeout: 4000 });
  check('score card shown with "does not change XP" disclaimer', /does not change your XP/.test(await p.locator('.cc-card').last().innerText()));
  check('campuslearn.state untouched after AI quiz', (await p.evaluate(() => localStorage.getItem('campuslearn.state'))) === '{"sentinel":1}');
  // short answer + grading
  await send(p, 'quiz me'); await p.waitForSelector('#cc-q-fmt'); await p.selectOption('#cc-q-fmt', 'short'); await p.selectOption('#cc-q-n', '3'); await p.selectOption('#cc-q-src', 'ai'); await p.locator('text=Start practice').last().click();
  await p.waitForSelector('textarea[aria-label="Your answer"]', { timeout: 6000 }); await p.fill('textarea[aria-label="Your answer"]', 'it uses base 2'); await p.click('text=Check my answer'); await p.waitForSelector('.cc-fb', { timeout: 6000 });
  check('short answer graded, labelled AI feedback / not official', /AI-generated feedback, not an official mark|keyword/.test(await p.locator('.cc-fb').last().innerText()), await p.locator('.cc-fb').last().innerText());
  check('no page errors', p.errs.length === 0, p.errs);
  await b.close(); srv.stop(); up.srv.close();
  const f = results.filter(r => !r.ok).length; console.log('QUIZ SUITE: ' + (results.length - f) + ' passed, ' + f + ' failed'); process.exit(f ? 1 : 0);
})().catch(e => { console.log('SUITE CRASH', e); process.exit(2); });
