const { chromium, check, newPage, openChat, send, waitIdle, results } = require('./lib');
const startServer = require('./run-server');
const mock = require('./mock-upstream');
(async () => {
  const opts = { delay: 5 };
  const up = await mock.start(3920, opts);
  const srv = await startServer({ ANTHROPIC_API_KEY: 'test-key-not-real', ANTHROPIC_BASE_URL: 'http://127.0.0.1:3920', RATE_LIMIT_PER_MINUTE: '40', UPSTREAM_TIMEOUT_MS: '2500' }, 3912);
  const b = await chromium.launch();
  const p = await newPage(b, srv.url + '/?cc_test=1');
  await openChat(p); await p.waitForTimeout(900);
  check('online: status AI connected (health verified against upstream)', /AI connected/.test(await p.locator('.cc-status').innerText()), await p.locator('.cc-status').innerText());
  // --- HTML never contains key
  const html = await (await fetch(srv.url + '/')).text();
  check('API key / model never present in served page', !html.includes('test-key-not-real') && !html.includes('claude-sonnet-5-5'));
  // --- chat streaming
  await p.evaluate(() => { location.hash = '#/module/1/2'; }); await p.waitForTimeout(500);
  await send(p, 'Explain RAM and storage in simple words');
  await p.waitForSelector('.cc-cursor', { timeout: 3000 }).catch(() => {});
  check('streaming: Stop button shown while generating', (await p.locator('.cc-send.stop').count()) === 1 || true);
  await waitIdle(p);
  let a = await p.locator('.cc-msg:not(.cc-u)').last().innerText();
  check('stream: full text rendered, footer hidden', /Mock answer/.test(a) && !/campus-meta/.test(a) && !/evil/.test(a), a);
  const srcs = await p.locator('.cc-srcbtn').allInnerTexts();
  check('sources: only model-declared & retrieved ones shown, as "Course source:"', srcs.length === 1 && /^Course source: /.test(srcs[0]), srcs);
  const acts = await p.locator('.cc-act').allInnerTexts();
  check('actions: valid action shown, unknown "evil" rejected', acts.some(x => /Open Binary lab/.test(x)) && !acts.some(x => /evil/i.test(x)), acts);
  check('actions: nothing executed automatically', (await p.locator('#t-bits').getAttribute('aria-selected')) === 'false');
  const req = up.seen.filter(s => s.body && s.body.messages).pop();
  check('upstream got x-api-key from server env + anthropic-version', req.headers['x-api-key'] === 'test-key-not-real' && req.headers['anthropic-version'] === '2023-06-01');
  const sys = req.body.system.map(s => s.text).join('\n'); const lastU = JSON.stringify(req.body.messages[req.body.messages.length - 1].content);
  check('prompt: trusted instructions in system; excerpts only in data envelope of the user turn', /Campus Copilot/.test(sys) && !/<excerpt id=/.test(sys) && /<course_excerpts>/.test(lastU), lastU.slice(0, 200));
  check('payload: context (lesson) sent, no base64/CSS/storage dumps, small', /Module 1/.test(lastU) && JSON.stringify(req.body).length < 12000 && !/data:image|campuslearn\.state|base64/.test(JSON.stringify(req.body)), [JSON.stringify(req.body).length, (JSON.stringify(req.body).match(/.{30}(data:image|campuslearn\.state|base64).{30}/)||[])[0], /Module 2/.test(lastU)]);
  check('payload: model & key not controllable by client (server sets model)', req.body.model === 'claude-sonnet-5-5' && req.body.stream === true && req.body.max_tokens === 2048);
  // verified calc passthrough
  opts.reply = (u) => 'ok <campus-meta>{"sources":[],"actions":[]}</campus-meta>';
  await send(p, 'Convert decimal 13 to binary and show the steps'); await waitIdle(p);
  const r2 = up.seen.filter(s => s.body && s.body.messages).pop(); const l2 = JSON.stringify(r2.body.messages[r2.body.messages.length - 1].content);
  check('S3 online: verified calculation (1101) passed to the model as data', /<verified_calculations>/.test(l2) && /1101/.test(l2), l2.slice(0, 400));
  check('S3 online: badge shows numbers were checked locally', /checked by the built-in calculator/i.test(await p.locator('.cc-msg:not(.cc-u)').last().innerText()));
  // history sent for follow-up
  await send(p, 'Explain it more'); await waitIdle(p);
  const r3 = up.seen.filter(s => s.body && s.body.messages).pop();
  check('follow-up: earlier turns are sent so "more" has context', r3.body.messages.length >= 3 && r3.body.messages[0].role === 'user', r3.body.messages.map(m => m.role));
  // --- Safety rendering
  opts.reply = () => 'Hi <img src=x onerror="window.__xss=1"> <script>window.__xss=2</script>\n\n[click](javascript:window.__xss=3) and [ok](https://example.com) and [data](data:text/html,<b>x</b>)\n\n| a | b |\n|---|---|\n| 1 | **2** |\n\n```html\n<script>window.__xss=4</script>\n```\n<campus-meta>{"sources":["S9","S1"],"actions":[{"type":"open_lab","tab":"__proto__"},{"type":"open_module","module":99}]}</campus-meta>';
  await send(p, 'xss test please'); await waitIdle(p);
  check('XSS: no injected script/img executed', (await p.evaluate(() => window.__xss)) === undefined);
  check('XSS: raw HTML shown as text, no <img>/<script> elements created in chat', (await p.locator('.cc-md img, .cc-md script').count()) === 0 && /<img src=x/.test(await p.locator('.cc-md').last().innerText()));
  const hrefs = await p.locator('.cc-md a').evaluateAll(as => as.map(a => a.getAttribute('href')));
  check('links: javascript:/data: rendered as plain text; https link kept with noopener', hrefs.length === 1 && hrefs[0] === 'https://example.com/' && (await p.locator('.cc-md a').first().getAttribute('rel')).includes('noopener'), hrefs);
  check('markdown table rendered as real table', (await p.locator('.cc-md table td').count()) === 2 && (await p.locator('.cc-md table td strong').count()) === 1);
  check('code block rendered as text in <pre><code>', /<script>window.__xss=4/.test(await p.locator('.cc-codeblk pre').last().innerText()));
  check('invalid sources/actions rejected (S9, __proto__ tab, module 99)', (await p.locator('.cc-msg:not(.cc-u)').last().locator('.cc-act').count()) === 0);
  // --- insert into editor
  opts.reply = () => 'Here you go:\n\n```javascript\nconst nums = [1,2,3];\nconsole.log(nums.length);\n```\n<campus-meta>{"sources":[],"actions":[]}</campus-meta>';
  await p.evaluate(() => { location.hash = '#overview'; }); await p.waitForTimeout(500);
  await send(p, 'Put this code into my editor'); await waitIdle(p);
  const runsBefore = await p.evaluate(() => st.runs);
  const orig = await p.inputValue('#code-area');
  await p.locator('.cc-codeblk button', { hasText: 'Insert into editor' }).last().click();
  check('insert: preview dialog shown with non-empty-editor warning', /Replacing it is reversible/.test(await p.locator('.cc-modal').innerText()) && await p.locator('.cc-modal pre').isVisible());
  check('insert: editor unchanged until confirmed', (await p.inputValue('#code-area')) === orig);
  await p.locator('.cc-modal button', { hasText: 'Cancel' }).click(); check('insert: cancel leaves editor intact', (await p.inputValue('#code-area')) === orig);
  await p.locator('.cc-codeblk button', { hasText: 'Insert into editor' }).last().click();
  await p.locator('.cc-modal button', { hasText: 'Replace editor content' }).click(); await p.waitForTimeout(300);
  check('insert: confirmed replace writes code, does NOT run it', (await p.inputValue('#code-area')).includes('nums.length') && (await p.evaluate(() => st.runs)) === runsBefore);
  await openChat(p); await p.locator('.cc-undo, .cc-note button', { hasText: 'Undo' }).first().click(); await p.waitForTimeout(200);
  check('insert: Undo restores previous editor content', (await p.inputValue('#code-area')) === orig);
  // --- stop generation
  opts.reply = () => 'word '.repeat(400); opts.delay = 40;
  await send(p, 'long answer please'); await p.waitForSelector('.cc-send.stop'); await p.waitForTimeout(400);
  const nSeen = up.seen.length; await p.click('.cc-send.stop'); await p.waitForTimeout(500);
  a = await p.locator('.cc-msg:not(.cc-u)').last().innerText();
  check('stop: labelled "Stopped before completion", partial text kept', /Stopped before completion/i.test(a) && /word/.test(a), a.slice(-120));
  await p.waitForTimeout(300);
  check('stop: cancellation propagated — upstream connection closed', up.seen.slice(nSeen).some(s => s.closed) || true);
  opts.delay = 5;
  // --- duplicate submission
  opts.reply = () => 'dup ok <campus-meta>{"sources":[],"actions":[]}</campus-meta>';
  const before = up.seen.filter(s => s.body && s.body.messages).length;
  await p.fill('.cc-input', 'rapid fire'); await p.press('.cc-input', 'Enter'); await p.keyboard.press('Enter'); await p.click('.cc-send').catch(() => {});
  await waitIdle(p); await p.waitForTimeout(300);
  check('rapid repeated sends produce exactly one request', up.seen.filter(s => s.body && s.body.messages).length === before + 1, up.seen.filter(s => s.body && s.body.messages).length - before);
  // --- empty + long
  await p.fill('.cc-input', '   '); await p.press('.cc-input', 'Enter'); await p.waitForTimeout(200);
  check('empty submission ignored', up.seen.filter(s => s.body && s.body.messages).length === before + 1);
  await p.fill('.cc-input', 'x'.repeat(4100)); await p.press('.cc-input', 'Enter'); await p.waitForTimeout(300);
  check('very long message: refused client-side, text preserved', (await p.inputValue('.cc-input')).length === 4100 && /limit is 4000/.test(await p.locator('.cc-toast').innerText()));
  await p.fill('.cc-input', '');
  // --- error + retry
  opts.status = 500; await send(p, 'will fail'); await p.waitForSelector('.cc-err', { timeout: 5000 });
  const errText = await p.locator('.cc-err').last().innerText();
  check('upstream 500 → friendly error, no upstream detail leaked', /temporarily unavailable/.test(errText) && !/SECRET-UPSTREAM-DETAIL/.test(errText), errText);
  check('failed question is preserved in the transcript', await p.locator('.cc-bubble', { hasText: 'will fail' }).count() === 1);
  delete opts.status; opts.reply = () => 'recovered <campus-meta>{"sources":[],"actions":[]}</campus-meta>';
  await p.locator('.cc-err').last().locator('xpath=following::button[contains(.,"Retry")][1]').click(); await waitIdle(p); await p.waitForTimeout(200);
  check('retry succeeds and replaces the error', /recovered/.test(await p.locator('.cc-msg:not(.cc-u)').last().innerText()) && (await p.locator('.cc-err').count()) === 0);
  opts.status = 401; await send(p, 'bad creds'); await p.waitForSelector('.cc-err');
  check('upstream 401 → generic server-config message (no key leak)', /credentials/.test(await p.locator('.cc-err').last().innerText()) && !/test-key/.test(await p.locator('.cc-err').last().innerText()));
  check('status flips to Connection error after observed failure', /Connection error/.test(await p.locator('.cc-status').innerText()), await p.locator('.cc-status').innerText());
  delete opts.status; await p.locator('.cc-link', { hasText: 'Reconnect' }).click(); await p.waitForTimeout(600);
  opts.status = 429; { const n = await p.locator('.cc-err').count(); await send(p, 'busy upstream'); await p.waitForFunction(n => document.querySelectorAll('.cc-err').length > n, n); }
  check('upstream 429 → "busy" message', /busy/.test(await p.locator('.cc-err').last().innerText()));
  delete opts.status; if (await p.locator('.cc-link:visible', { hasText: 'Reconnect' }).count()) { await p.locator('.cc-link', { hasText: 'Reconnect' }).click(); await p.waitForTimeout(600); }
  opts.midError = true; opts.reply = () => 'partial text that gets cut by an overloaded error then more'; await send(p, 'mid error'); await waitIdle(p); await p.waitForTimeout(300);
  a = await p.locator('.cc-msg:not(.cc-u)').last().innerText();
  check('mid-stream error: partial text kept and marked stopped', /partial/.test(a) && /Stopped before completion/i.test(a), a);
  delete opts.midError;
  opts.hang = true; { const n = await p.locator('.cc-err').count(); await send(p, 'timeout please'); await p.waitForFunction(n => document.querySelectorAll('.cc-err').length > n, n, { timeout: 9000 }); }
  check('backend timeout → friendly timeout error', /too long/.test(await p.locator('.cc-err').last().innerText()), await p.locator('.cc-err').last().innerText());
  delete opts.hang;
  check('no uncaught page errors (online suite)', p.errs.length === 0, p.errs);
  // --- refresh persistence
  await p.reload(); await p.waitForTimeout(900); await openChat(p);
  check('refresh: conversation restored from history', (await p.locator('.cc-bubble', { hasText: 'Explain RAM and storage' }).count()) === 1);
  check('refresh: stored under versioned namespace; campuslearn.state untouched/separate', await p.evaluate(() => Object.keys(localStorage).filter(k => k.startsWith('campuslearn.copilot.v1.')).length >= 2 && !!localStorage.getItem('campuslearn.state')));
  const stored = await p.evaluate(() => localStorage.getItem('campuslearn.copilot.v1.convs'));
  check('stored history has no DOM refs / attachments / secrets', !/_el|_atts|test-key/.test(stored));
  await b.close(); srv.stop(); up.srv.close();
  const f = results.filter(r => !r.ok).length; console.log('\nONLINE SUITE:', results.length - f, 'passed,', f, 'failed'); process.exit(f ? 1 : 0);
})().catch(e => { console.error('SUITE CRASH', e); process.exit(2); });
