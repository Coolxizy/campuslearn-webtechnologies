const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const results = [];
function check(name, ok, detail) { results.push({ name, ok: !!ok, detail }); console.log((ok ? 'PASS ' : 'FAIL ') + name + (ok ? '' : '  -> ' + (detail === undefined ? '' : JSON.stringify(detail)))); }
async function newPage(browser, url, opts = {}) {
  const ctx = await browser.newContext({ viewport: opts.viewport || { width: 1366, height: 800 }, ...(opts.ctx || {}) });
  const p = await ctx.newPage(); p.errs = [];
  p.on('pageerror', e => p.errs.push('PAGEERR ' + e.message)); p.on('console', m => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) p.errs.push('CONSOLE ' + m.text()); });
  await p.goto(url); await p.waitForTimeout(700); return p;
}
async function openChat(p) { if (!(await p.locator('#cc-panel').isVisible())) await p.click('#cc-launcher'); await p.waitForSelector('#cc-panel:not([hidden])'); }
async function send(p, text) { await p.fill('.cc-input', text); await p.press('.cc-input', 'Enter'); }
async function lastAssistant(p) { const l = p.locator('.cc-msg:not(.cc-u)').last(); return l; }
async function waitIdle(p, ms = 8000) { await p.waitForFunction(() => !document.querySelector('.cc-cursor') && !document.querySelector('.cc-send.stop'), null, { timeout: ms }); }
module.exports = { chromium, results, check, newPage, openChat, send, lastAssistant, waitIdle };
