// Tests AI_PROVIDER=deepseek-proxy against a tiny stand-in for the local proxy (NOT the real DeepSeek service).
const http = require('http'); const startServer = require('./run-server'); const { check, results } = require('./lib');
(async () => {
  let ready = 200, seen = [], bodies = [], sessions = [];
  const fake = http.createServer((req, res) => {
    seen.push(req.method + ' ' + req.url + ' key=' + (req.headers['x-api-key'] || '') + ' auth=' + (req.headers.authorization || ''));
    if (req.url === '/readyz') { res.writeHead(ready, { 'content-type': 'application/json' }); return res.end('{}'); }
    if (req.url === '/v1/messages') { let b = ''; req.on('data', c => b += c); req.on('end', () => bodies.push(JSON.parse(b))); sessions.push(req.headers['x-agent-session']); res.writeHead(200, { 'content-type': 'text/event-stream' });
      for (const e of [['message_start', { type: 'message_start' }], ['content_block_delta', { type: 'content_block_delta', delta: { type: 'text_delta', text: 'Hello from proxy' } }], ['message_stop', { type: 'message_stop' }]]) res.write(`event: ${e[0]}\ndata: ${JSON.stringify(e[1])}\n\n`); return res.end(); }
    res.writeHead(404); res.end();
  }); await new Promise(r => fake.listen(9656, '127.0.0.1', r));
  const env = { AI_PROVIDER: 'deepseek-proxy', DEEPSEEK_PROXY_URL: 'http://127.0.0.1:9656', ANTHROPIC_BASE_URL: 'http://127.0.0.1:1', ANTHROPIC_API_KEY: 'real-key-should-not-be-sent', DEEPSEEK_PROXY_KEY: 'pk' };
  let srv = await startServer(env, 3951); const get = async () => (await (await fetch(srv.url + '/api/health')).json()).status;
  check('ready when proxy /readyz is 200', await get() === 'ready');
  const r = await fetch(srv.url + '/api/chat', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ mode: 'auto', messages: [{ role: 'user', content: 'hi' }], excerpts: [], context: {} }) });
  const t = await r.text(); check('chat streams through the proxy', /Hello from proxy/.test(t), t.slice(0, 200));
  check('ANTHROPIC_* env vars are ignored in this mode (own key not leaked)', !seen.some(s => /real-key-should-not-be-sent/.test(s)) && seen.some(s => /\/v1\/messages key=local-proxy auth=Bearer pk/.test(s)), seen);
  const post = body => fetch(srv.url + '/api/chat', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }).then(r => r.text());
  await post({ mode: 'auto', messages: [{ role: 'user', content: 'What is RAM?' }, { role: 'assistant', content: 'RAM is temporary memory.' }, { role: 'user', content: 'And a CPU?' }], excerpts: [], context: {} });
  const last = bodies[bodies.length - 1];
  check('proxy mode sends ONE user message (no User:/Assistant: transcript to the proxy)', last.messages.length === 1 && last.messages[0].role === 'user', last.messages.length);
  const txt = last.messages[0].content;
  check('earlier turns are labelled context-only; new message is marked and last', /EARLIER CONVERSATION[^]*do NOT answer/.test(txt) && /What is RAM\?/.test(txt) && txt.trimEnd().endsWith('And a CPU?\n>>>'), txt);
  check('each request gets its own proxy session (no double history via the proxy chain)', sessions.length >= 2 && new Set(sessions).size === sessions.length && sessions.every(x => /^campus-/.test(x)), sessions);
  srv.stop(); ready = 503; srv = await startServer(env, 3952); const s2 = await (await fetch(srv.url + '/api/health')).json();
  check('503 from /readyz → login_needed (not "connected")', s2.status === 'login_needed', s2);
  srv.stop(); fake.close(); srv = await startServer(env, 3953); const s3 = await (await fetch(srv.url + '/api/health')).json();
  check('proxy not running → unreachable', s3.status === 'unreachable', s3); srv.stop();
  const f = results.filter(x => !x.ok).length; console.log('DEEPSEEK-MODE SUITE: ' + (results.length - f) + ' passed, ' + f + ' failed'); process.exit(f ? 1 : 0);
})().catch(e => { console.log('CRASH', e); process.exit(2); });
