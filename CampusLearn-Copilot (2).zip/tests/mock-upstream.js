'use strict';
// Fake Anthropic API for tests ONLY. It speaks the documented SSE shape; it is NOT a real AI.
const http = require('node:http');
function start(port, opts = {}) {
  const seen = [];
  const srv = http.createServer((req, res) => {
    let body = ''; req.on('data', c => body += c);
    req.on('end', () => {
      if (req.url.startsWith('/v1/models')) { res.writeHead(opts.badKey ? 401 : 200, { 'content-type': 'application/json' }); return res.end('{"data":[]}'); }
      let j = {}; try { j = JSON.parse(body); } catch (_) {}
      seen.push({ headers: req.headers, body: j });
      if (opts.status) { res.writeHead(opts.status, { 'content-type': 'application/json' }); return res.end(JSON.stringify({ type: 'error', error: { type: 'x', message: 'SECRET-UPSTREAM-DETAIL' } })); }
      if (opts.hang) { req.on('close', () => { seen.push({ closed: true }); }); res.on('close', () => seen.push({ closed: true })); return; }
      const system = (j.system || []).map(s => s.text).join('\n');
      const lastUser = j.messages && j.messages[j.messages.length - 1];
      const userText = Array.isArray(lastUser && lastUser.content) ? lastUser.content.map(c => c.text).join('\n') : (lastUser && lastUser.content) || '';
      if (j.stream === false) {
        res.writeHead(200, { 'content-type': 'application/json' });
        const isQuiz = /practice questions/.test(system);
        const text = isQuiz ? JSON.stringify({ questions: [{ q: 'Mock Q?', options: ['a', 'b', 'c', 'd'], answer: 2, explain: 'Because.', why: ['no', 'no', 'yes', 'no'] }] }) : JSON.stringify({ verdict: 'partial', feedback: 'Mock feedback.' });
        return res.end(JSON.stringify({ content: [{ type: 'text', text }], stop_reason: 'end_turn' }));
      }
      res.writeHead(200, { 'content-type': 'text/event-stream' });
      const ev = (t, d) => res.write('event: ' + t + '\ndata: ' + JSON.stringify(d) + '\n\n');
      ev('message_start', { type: 'message_start', message: { id: 'm', role: 'assistant', content: [] } });
      ev('content_block_start', { type: 'content_block_start', index: 0, content_block: { type: 'text', text: '' } });
      const reply = opts.reply ? opts.reply(userText, system, j) : 'Mock answer. RAM is temporary memory; storage keeps files.\n\n```javascript\nconsole.log("hi");\n```\n<campus-meta>{"sources":["S1"],"actions":[{"type":"open_lab","tab":"bits"},{"type":"evil","x":1}]}</campus-meta>';
      const parts = reply.match(/[\s\S]{1,12}/g) || [];
      let i = 0;
      const tick = () => {
        if (res.destroyed) return;
        if (opts.midError && i === 2) { ev('error', { type: 'error', error: { type: 'overloaded_error', message: 'Overloaded' } }); return res.end(); }
        if (i < parts.length) { ev('content_block_delta', { type: 'content_block_delta', index: 0, delta: { type: 'text_delta', text: parts[i++] } }); return setTimeout(tick, opts.delay || 5); }
        ev('content_block_stop', { type: 'content_block_stop', index: 0 }); ev('message_delta', { type: 'message_delta', delta: { stop_reason: 'end_turn' } }); ev('message_stop', { type: 'message_stop' }); res.end();
      };
      tick();
    });
  });
  return new Promise(r => srv.listen(port, '127.0.0.1', () => r({ srv, seen })));
}
module.exports = { start };
