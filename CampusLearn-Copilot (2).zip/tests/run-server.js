// Helper for tests: start the app server with env overrides, return {url, stop, proc}
const { spawn } = require('node:child_process'); const path = require('node:path');
module.exports = function startServer(env, port) {
  return new Promise((resolve, reject) => {
    const proc = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], { env: { ...process.env, PORT: String(port), HOST: '127.0.0.1', ...env }, stdio: ['ignore', 'pipe', 'pipe'], cwd: path.join(__dirname, '..') });
    let out = ''; proc.stdout.on('data', d => { out += d; if (/running at/.test(out)) resolve({ url: 'http://127.0.0.1:' + port, proc, logs: () => out, stop: () => proc.kill() }); });
    proc.stderr.on('data', d => { out += d; }); proc.on('error', reject); setTimeout(() => reject(new Error('server start timeout: ' + out)), 8000);
  });
};
