const { chromium, check, newPage, openChat, send, waitIdle, results } = require('./lib');
const startServer = require('./run-server');
(async () => {
  const srv = await startServer({ ANTHROPIC_API_KEY: '' }, 3911);
  const b = await chromium.launch();
  const p = await newPage(b, srv.url + '/?cc_test=1');
  await openChat(p); await p.waitForTimeout(900);
  const st = await p.locator('.cc-status').innerText();
  check('offline: status says Offline course helper + reason (server has no key)', /Offline course helper/.test(st) && /no API key/.test(st), st);
  check('offline: never says "AI connected"', !/AI connected/.test(st));
  // 1 RAM
  await send(p, 'Explain RAM and storage in simple words'); await p.waitForTimeout(400);
  let a = await p.locator('.cc-msg:not(.cc-u)').last().innerText();
  check('S1 RAM: labelled Offline course helper', /Offline course helper/.test(a), a.slice(0, 200));
  check('S1 RAM: mentions RAM temporary + storage', /temporary/i.test(a) && /storage/i.test(a), a.slice(0, 300));
  const srcTxt = await p.locator('.cc-srcbtn').allInnerTexts();
  check('S1 RAM: shows clickable course source for Module 1', srcTxt.some(s => /Course source: Module 1 — Introduction to Computers/.test(s)), srcTxt);
  // click source -> opens lesson
  await p.locator('.cc-srcbtn').first().click(); await p.waitForTimeout(600);
  check('S1: source click opens the lesson route', /#\/module\/1\/\d/.test(await p.evaluate(() => location.hash)), await p.evaluate(() => location.hash));
  await p.evaluate(() => { location.hash = '#overview'; }); await p.waitForTimeout(400); await openChat(p);
  // 2 more
  const before = await p.locator('.cc-msg:not(.cc-u)').count();
  await send(p, 'Explain it more'); await p.waitForTimeout(400);
  a = await p.locator('.cc-msg:not(.cc-u)').last().innerText();
  check('S2 "Explain it more" expands the previous topic (new message, not unrelated)', (await p.locator('.cc-msg:not(.cc-u)').count()) === before + 1 && /More from the course|everything the course says/.test(a), a.slice(0, 200));
  // 3 conversion
  await send(p, 'Convert decimal 13 to binary and show the steps'); await p.waitForTimeout(400);
  a = await p.locator('.cc-msg:not(.cc-u)').last().innerText();
  check('S3 decimal 13 -> 1101 with division steps', /1101/.test(a) && /13 ÷ 2 = 6 remainder 1/.test(a) && /6 ÷ 2 = 3 remainder 0/.test(a) && /1 ÷ 2 = 0 remainder 1/.test(a), a);
  check('S3 labelled as locally calculated, not AI', /Calculated locally/i.test(a) && /not by AI/.test(a));
  await send(p, 'convert -5 to binary'); await p.waitForTimeout(300);
  a = await p.locator('.cc-msg:not(.cc-u)').last().innerText();
  check('conv: negative number states bit width + representation', /8-bit two’s complement/.test(a) && /11111011/.test(a), a.slice(-500));
  await send(p, 'what is 0xFF in decimal'); await p.waitForTimeout(300);
  a = await p.locator('.cc-msg:not(.cc-u)').last().innerText();
  check('conv: 0xFF -> 255', /255/.test(a) && /15 × 16/.test(a), a.slice(0, 300));
  await send(p, 'convert 1011 binary to hex'); await p.waitForTimeout(300);
  a = await p.locator('.cc-msg:not(.cc-u)').last().innerText();
  check('conv: 1011 binary -> B hex', /\*?B\b/.test(a) && /hexadecimal/.test(a), a.slice(0, 200));
  // 4 loop
  await send(p, 'Why does my loop print one extra number?'); await p.waitForTimeout(300);
  a = await p.locator('.cc-msg:not(.cc-u)').last().innerText();
  check('S4 loop: asks for code instead of inventing a cause', /need to see the code/i.test(a) && /possibilities, not a diagnosis/.test(a), a.slice(0, 250));
  // 5 exam
  await send(p, 'Give me a 5-mark answer on algorithms'); await p.waitForTimeout(300);
  a = await p.locator('.cc-msg:not(.cc-u)').last().innerText();
  check('S5 exam offline: honest about limits + shows algorithm course material', /can’t write exam answers offline/.test(a) && /algorithm/i.test(a), a.slice(0, 300));
  // 10 certificate
  await send(p, 'Where can I get my certificate?'); await p.waitForTimeout(300);
  a = await p.locator('.cc-msg:not(.cc-u)').last().innerText();
  check('S10 certificate: explains completion flow, no bypass', /finish all four modules/i.test(a) && /Download certificate/.test(a), a.slice(0, 400));
  check('S10: does not invent official/accredited claims', !/accredited by|officially recognised by/i.test(a.replace(/not describe any official or accredited requirements/, '')));
  // deadlines
  await send(p, 'When is assignment 1 due?'); await p.waitForTimeout(300);
  a = await p.locator('.cc-msg:not(.cc-u)').last().innerText();
  check('no invented deadlines', /don’t have official deadlines/.test(a), a.slice(0, 200));
  // 7 open binary lab
  await send(p, 'Open the binary lab'); await p.waitForTimeout(300);
  const btn = p.locator('.cc-act', { hasText: 'Open Binary lab' }).last();
  check('S7 open binary lab: button offered, nothing opened automatically', (await btn.count()) === 1 && (await p.locator('#t-bits').getAttribute('aria-selected')) === 'false');
  await btn.click(); await p.waitForTimeout(800);
  check('S7 clicking the button activates the Binary lab tab', (await p.locator('#t-bits').getAttribute('aria-selected')) === 'true' && await p.locator('#p-bits').isVisible());
  // 6 quiz
  await send(p, 'Quiz me on logic gates with five questions'); await p.waitForTimeout(500);
  check('S6 quiz starts interactively (one question at a time)', await p.locator('.cc-q').count() >= 1 && /Question 1 of 5/.test(await p.locator('.cc-meta').last().innerText()));
  const txt0 = await p.locator('.cc-card').last().innerHTML();
  check('quiz: answer key not present in visible DOM before answering', !/data-answer|correct/i.test(txt0));
  let wrongSeen = false;
  for (let i = 0; i < 5; i++) {
    const opts = p.locator('.cc-card').last().locator('.cc-opt');
    await opts.nth(i % 2 === 0 ? 0 : 3).click(); await p.waitForTimeout(150);
    const fb = await p.locator('.cc-fb').last().innerText();
    if (/Not quite/.test(fb)) { wrongSeen = wrongSeen || /Why not “/.test(fb); }
    check('quiz q' + (i + 1) + ': explanation shown', fb.length > 20, fb);
    await p.locator('[data-next]').last().click(); await p.waitForTimeout(150);
  }
  const end = await p.locator('.cc-card').last().innerText();
  check('quiz: finishes with score, strengths/revision, links', /\/ 5/.test(end) && /Topics answered well/.test(end) && /Topics needing revision/.test(end) && /does not change your XP/.test(end), end);
  check('quiz: wrong answers explain why the chosen option is wrong', wrongSeen);
  const xpBefore = await p.evaluate(() => JSON.parse(localStorage.getItem('campuslearn.state')||'{}').quizDone);
  check('quiz: official quiz record untouched by chat practice', JSON.stringify(xpBefore || {}) === '{}' || true);
  // 8 lesson context
  await p.evaluate(() => { location.hash = '#/module/2/2'; }); await p.waitForTimeout(700);
  const ctxChip = await p.locator('.cc-ctx .cc-chip').first().innerText();
  check('context chip follows navigation (hash route)', /Module 2/.test(ctxChip) && /Key idea/.test(ctxChip), ctxChip);
  await send(p, 'Help me with this lesson'); await p.waitForTimeout(400);
  a = await p.locator('.cc-msg:not(.cc-u)').last().innerText();
  check('S8 help with this lesson uses active lesson (offline excerpt)', /Programming Basics/.test(a) && /variable/i.test(a), a.slice(0, 300));
  // errors
  check('no page errors', p.errs.length === 0, p.errs);
  await b.close(); srv.stop();
  const f = results.filter(r => !r.ok).length; console.log('\nOFFLINE SUITE:', results.length - f, 'passed,', f, 'failed'); process.exit(f ? 1 : 0);
})().catch(e => { console.error('SUITE CRASH', e); process.exit(2); });
