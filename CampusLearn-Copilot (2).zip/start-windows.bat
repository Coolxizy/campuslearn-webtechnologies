@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js was not found. Install the LTS version from https://nodejs.org/ and run this file again.
  pause
  exit /b 1
)
if not exist ".env" (
  echo No .env file yet. Copying .env.example to .env ...
  copy ".env.example" ".env" >nul
  echo Open .env in Notepad, replace your-api-key-here with your real key, save, then run this file again.
  notepad ".env"
  pause
  exit /b 0
)
echo Starting CampusLearn on http://localhost:3000  (press Ctrl+C to stop)
start "" "http://localhost:3000"
node server.js
pause
