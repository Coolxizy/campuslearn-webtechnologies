@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js was not found. Install the LTS version from https://nodejs.org/ and run this file again.
  pause
  exit /b 1
)
if not exist "deepseek-proxy\deepseek-auth.json" (
  echo.
  echo === First-time DeepSeek login ===
  echo A menu will open. Choose option 1, log in to DeepSeek in the Chrome window that appears,
  echo send a short message like "ok", then come back here and press Enter.
  echo.
  pushd deepseek-proxy
  call npm run auth
  popd
  if not exist "deepseek-proxy\deepseek-auth.json" (
    echo Login was not saved. Run this file again to retry.
    pause
    exit /b 1
  )
)
echo Starting the DeepSeek proxy in a separate window...
start "DeepSeek proxy (leave open)" cmd /k "cd /d %~dp0deepseek-proxy && set NON_INTERACTIVE=1 && node server.js"
timeout /t 4 /nobreak >nul
set AI_PROVIDER=deepseek-proxy
echo Starting CampusLearn on http://localhost:3000  (press Ctrl+C to stop)
start "" "http://localhost:3000"
node server.js
pause
