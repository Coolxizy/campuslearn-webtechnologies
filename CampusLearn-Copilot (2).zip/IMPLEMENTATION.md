# Implementation summary

## Integration risks found in the original file (inspected before editing) and how they were handled
| Risk | Handling |
|---|---|
| Core data (`modules`, quiz bank, state) are top-level `const/let`, not on `window` | Small explicit `window.CampusBridge` added; Copilot reads through it only (read-only for progress). |
| Several global keyboard shortcuts (F, T, `/`, arrows) and two palettes | Panel/composer stop key propagation; tested that typing does not trigger site shortcuts. |
| Hash router (`#/module/N/S`) | Copilot only reads the hash and navigates through allowlisted actions; context chip follows route changes. |
| Single storage key `campuslearn.state` | Never read-modify-written by Copilot; own namespace `campuslearn.copilot.v1.*`; verified byte-for-byte untouched. |
| Existing dialogs/focus handling | Copilot is non-modal on desktop, a labelled dialog with focus trap on mobile; Escape restores focus to launcher. |
| Playground runs code with `new Function` (no isolation) | Unchanged (existing behaviour). Copilot never runs code; Insert-into-editor needs preview + click. |
| Site XP/quiz/certificate logic | Copilot has no write path to it; chat quizzes are scored separately as "practice score only". |
| `#/complete` reachable by hash | Pre-existing; left unchanged. |
| ~1.5 MB single file | Copilot adds ~200 KB inline, built lazily on first use; index built once from live course data. |

## Architecture
- Frontend: one IIFE injected before `</body>`; scoped `.cc-*` CSS on the site's tokens (light/dark/custom). No `innerHTML` – Markdown is rendered to DOM nodes. Errors are caught so a Copilot failure cannot break the page.
- Backend (`server.js`): `GET /api/health`, `POST /api/chat` (SSE). Validation (roles, sizes, modes, excerpt count), 64 KB body cap (413), per-IP rate / daily / concurrency limits, origin allowlist with exact-origin CORS, upstream timeout and cancellation on client abort, generic errors, no content in logs. Only the HTML is served statically.
- Prompting: trusted rules in `system`; student text, excerpts, attachments in an XML-escaped data envelope. Client cannot set model or system prompt. Model sources/actions are accepted only if they match sent excerpts / the allowlist.
- Actions (open module/lab/quiz/dialog) are validated and run only on click. Number conversions are computed locally and passed to the model as verified data.

## Provider format
Request/stream format follows the Anthropic Messages API streaming docs (SSE events `content_block_delta`/`text_delta`, `message_delta`, `message_stop`, `error`). The HTTP-status → friendly-error mapping was **not** re-verified against the provider's errors page (the fetch failed in this session).
