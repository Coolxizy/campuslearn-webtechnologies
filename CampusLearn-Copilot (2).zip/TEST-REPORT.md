# Test report

All automated suites live in `tests/` and ran green on the final build (146 checks, headless Chromium + Node 22, Linux).

| Suite | Result | Covers |
|---|---|---|
| `e2e-offline.js` | 32/32 | Offline helper status honesty; RAM explanation with clickable course source; "explain more"; decimal 13→1101 with steps; −5 with explicit 8-bit two's complement; hex/binary; quiz flow; lesson help; certificate question (no invented rules) |
| `e2e-online.js` | 42/42 | Against a **mock** provider: health states, streaming, stop, retry, copy, source/action footer filtering, injection attempts, error states (401, 5xx, mid-stream error, hang), key never in page |
| `server.test.js` | 29/29 | Health, static serving limits, validation, 413, origin/CORS, XML-escaping, quiz/grade tasks, rate limit, concurrency, timeout, abort cancellation, no secrets/content in logs |
| `e2e-misc.js` | 34/34 | Mobile 390×844 / tablet / desktop (no overflow, composer visible), long code scrolls in block, theme switch while open, shortcut isolation, Escape+focus restore, rename/export/delete/clear/save-toggle, reload persistence, localStorage blocked, attachments menu, lesson navigation, regression vs original (lesson route, theme, `campuslearn.state` keys, no new errors), state untouched |
| `e2e-quiz.js` | 9/9 | AI-written MCQ + short-answer grading via mock, key hidden until answered, practice score separate, state untouched |

Screenshots: `screenshots/` (mobile, tablet, desktop light; desktop dark).

## NOT verified – please read
- **The real Anthropic API was never called.** No credential was available. Everything "online" was tested against a mock server written to the documented stream format. First real-key run may need small adjustments.
- Model behaviour is untested: debug mode asking for code, 5-mark answer quality, compliance with the sources footer, refusal of injected instructions by a real model. (Server-side filtering of sources/actions is tested; the model's tutoring quality is not.)
- Provider error-code → message mapping not re-checked against the live docs.
- Mobile soft-keyboard handling (`visualViewport`) and IME composition were tested only in emulation, not on real devices/keyboards. Screen readers were not run; accessibility is by construction (roles, labels, focus management) plus automated focus/Escape checks.
- Windows launcher `start-windows.bat` was not executed (Linux sandbox).
- Original-flow regression covered lesson routing, theme, state keys and error-free load. Lab quiz XP, code runner, focus timer, notes and certificate generation were not re-driven end to end beyond confirming they are untouched.
- Playground code still runs unsandboxed through the site's existing `new Function` (pre-existing risk, unchanged).
- Sources appear only when the model declares them in its footer; an answer without one shows none.

## DeepSeek route (added later)
- `tests/deepseek-mode.test.js` 5/5 against a stand-in for the local proxy: health ready / login_needed / unreachable, streaming passthrough, Anthropic env vars ignored in this mode.
- Also run by hand: the real FreeDeepseekAPI proxy code was started with a **fake** login. It accepted this server's `/v1/messages` requests (system prompt array, streaming) and failed only at the final call to deepseek.com, which the sandbox cannot reach; the site showed the friendly "temporarily unavailable" message.
- **Not verified:** a real DeepSeek login, a real DeepSeek answer, whether DeepSeek follows the sources/actions footer, whether AI-written quizzes and short-answer grading return valid JSON from DeepSeek (if not, the app falls back to the question bank / keyword check), and `start-with-deepseek.bat` / Chrome login on Windows.
